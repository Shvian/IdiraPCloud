#Requires -Version 5.1
# Shared by the task scripts: loads the module and connects if no session exists yet.

$modulePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'IdiraPCloud\IdiraPCloud.psd1'
Import-Module $modulePath -Force:$false -ErrorAction Stop

function Test-PCloudSessionUsable {
    # A session is usable if it exists and either renews itself or its token has not expired.
    $s = Get-PCloudSession
    if (-not $s) { return $false }
    if ($s.CanRefresh) { return $true }
    if ($null -ne $s.ExpiresAt -and $s.ExpiresAt -le (Get-Date)) {
        Write-Warning 'The current session token has expired.'
        return $false
    }
    return $true
}

function Connect-PCloudIfNeeded {
    <#
        Reuses an active session. Otherwise prompts for whatever is missing:
        the sign-in method, the subdomain (via New-PCloudSession), and the credential or MFA steps.
    #>
    param(
        [string]$IdentityUrl,
        [string]$Subdomain,
        [string]$PCloudUrl,
        [System.Management.Automation.PSCredential]$Credential,
        [string]$AuthMethod
    )
    if (Test-PCloudSessionUsable) {
        Write-Verbose ('Using the existing session for {0}' -f (Get-PCloudSession).PCloudUrl)
        return
    }

    Write-Host 'No active Privilege Cloud session. Please sign in.' -ForegroundColor Yellow
    if (-not $AuthMethod) {
        Write-Host '  1) Interactive - your Identity user, with MFA'
        Write-Host '  2) Service user - OAuth2 client credentials'
        while (-not $AuthMethod) {
            $choice = Read-Host 'Choose sign-in method [1]'
            if (-not $choice -or $choice -eq '1') { $AuthMethod = 'Interactive' }
            elseif ($choice -eq '2') { $AuthMethod = 'ServiceUser' }
            else { Write-Host 'Enter 1 or 2.' }
        }
    }

    $p = @{ AuthMethod = $AuthMethod }
    if ($IdentityUrl) { $p['IdentityUrl'] = $IdentityUrl }
    if ($Credential) { $p['Credential'] = $Credential }
    if ($PCloudUrl) { $p['PCloudUrl'] = $PCloudUrl }
    if ($Subdomain) { $p['Subdomain'] = $Subdomain }
    # New-PCloudSession prompts for the subdomain if missing, then for the credential (ServiceUser)
    # or the user name and each MFA step (Interactive).
    New-PCloudSession @p
}
