#Requires -Version 5.1
# Internal helpers: session state, URL building, request execution, error handling and paging.
# Written for Windows PowerShell 5.1 (no PS7-only operators or parameters).

$script:PCloudSession = $null

function Initialize-PCloudTls {
    # Windows PowerShell 5.1 may still offer SSL3/TLS 1.0/1.1. Allow only TLS 1.2 (and TLS 1.3 where
    # the OS/.NET supports it). Certificate validation is never relaxed by this module.
    try {
        $protocols = [Net.SecurityProtocolType]::Tls12
        $names = [Enum]::GetNames([Net.SecurityProtocolType])
        if ($names -contains 'Tls13') { $protocols = $protocols -bor [Net.SecurityProtocolType]'Tls13' }
        if ([Net.ServicePointManager]::SecurityProtocol -ne $protocols) {
            [Net.ServicePointManager]::SecurityProtocol = $protocols
        }
    } catch {
        Write-Verbose "Could not adjust TLS settings: $($_.Exception.Message)"
    }
}

function Assert-PCloudHttpsUrl {
    # Secrets and tokens are only ever sent over HTTPS.
    param([Parameter(Mandatory = $true)][string]$Url, [string]$Name = 'URL')
    $u = $null
    if (-not [Uri]::TryCreate($Url, [UriKind]::Absolute, [ref]$u) -or $u.Scheme -ne 'https') {
        throw "$Name must be an https:// URL (got '$Url')."
    }
}

function ConvertTo-PCloudSecureString {
    # Wraps a plain string (e.g. a token from an HTTP response) in a read-only SecureString.
    param([string]$PlainText)
    if (-not $PlainText) { return $null }
    $ss = New-Object System.Security.SecureString
    foreach ($ch in $PlainText.ToCharArray()) { $ss.AppendChar($ch) }
    $ss.MakeReadOnly()
    return $ss
}

function Clear-PCloudBytes {
    # Zeroes a byte buffer that held a request body (may contain secrets).
    param($Bytes)
    if ($Bytes -is [byte[]]) { [Array]::Clear($Bytes, 0, $Bytes.Length) }
}

function Assert-PCloudSession {
    if ($null -eq $script:PCloudSession) {
        throw "No Privilege Cloud session. Run New-PCloudSession first."
    }
}

function ConvertTo-PCloudPathSegment {
    # URL-encode a single path segment (safe names, member names, platform IDs).
    param([Parameter(Mandatory = $true)][string]$Value)
    return [System.Uri]::EscapeDataString($Value)
}

function ConvertTo-PCloudQueryString {
    param([hashtable]$Query)
    if ($null -eq $Query -or $Query.Count -eq 0) { return '' }
    $pairs = New-Object System.Collections.Generic.List[string]
    foreach ($key in $Query.Keys) {
        $value = $Query[$key]
        if ($null -eq $value) { continue }
        if ($value -is [string] -and $value -eq '') { continue }
        if ($value -is [bool]) { $value = $value.ToString().ToLowerInvariant() }
        if ($value -is [System.Management.Automation.SwitchParameter]) { $value = $value.IsPresent.ToString().ToLowerInvariant() }
        $pairs.Add(('{0}={1}' -f [System.Uri]::EscapeDataString([string]$key), [System.Uri]::EscapeDataString([string]$value)))
    }
    if ($pairs.Count -eq 0) { return '' }
    return '?' + ($pairs -join '&')
}

function ConvertFrom-PCloudSecureString {
    param([Parameter(Mandatory = $true)][System.Security.SecureString]$SecureString)
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

function Get-PCloudErrorDetail {
    # Extract status code and the Privilege Cloud ErrorCode/ErrorMessage from a failed web request (PS 5.1).
    param([Parameter(Mandatory = $true)][System.Management.Automation.ErrorRecord]$ErrorRecord)

    $statusCode = $null
    $rawBody = $null
    $response = $null
    if ($ErrorRecord.Exception -and ($ErrorRecord.Exception.PSObject.Properties.Name -contains 'Response')) {
        $response = $ErrorRecord.Exception.Response
    }
    if ($null -ne $response) {
        try { $statusCode = [int]$response.StatusCode } catch { $statusCode = $null }
    }

    if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
        $rawBody = $ErrorRecord.ErrorDetails.Message
    } elseif ($null -ne $response) {
        try {
            $stream = $response.GetResponseStream()
            if ($stream.CanSeek) { $stream.Position = 0 }
            $reader = New-Object System.IO.StreamReader($stream)
            $rawBody = $reader.ReadToEnd()
            $reader.Dispose()
        } catch {
            $rawBody = $null
        }
    }

    $errorCode = $null
    $errorMessage = $null
    if ($rawBody) {
        try {
            $parsed = $rawBody | ConvertFrom-Json -ErrorAction Stop
            if ($parsed.ErrorCode) { $errorCode = $parsed.ErrorCode }
            if ($parsed.ErrorMessage) { $errorMessage = $parsed.ErrorMessage }
            if (-not $errorMessage -and $parsed.error_description) { $errorMessage = $parsed.error_description }
            if (-not $errorMessage -and $parsed.error) { $errorMessage = [string]$parsed.error }
            # Validation errors (e.g. PASWS167E 'There are some invalid parameters') list the offending fields in Details.
            if ($parsed.Details) {
                $d = ConvertTo-Json -InputObject $parsed.Details -Compress -Depth 5
                if ($d.Length -gt 800) { $d = $d.Substring(0, 800) + '...' }
                if ($errorMessage) { $errorMessage = '{0} | Details: {1}' -f $errorMessage, $d } else { $errorMessage = $d }
            }
        } catch {
            # Not JSON (for example an HTML error page): keep a short plain-text summary.
            $text = $rawBody
            if ($text -match '(?is)<html|<!doctype') {
                $text = $text -replace '(?is)<(script|style)[^>]*>.*?</\1>', ' '
                $text = $text -replace '(?s)<[^>]+>', ' '
            }
            $text = ($text -replace '\s+', ' ').Trim()
            if ($text.Length -gt 300) { $text = $text.Substring(0, 300) + '...' }
            $errorMessage = $text
        }
    }
    if (-not $errorMessage) { $errorMessage = $ErrorRecord.Exception.Message }

    return [pscustomobject]@{
        StatusCode   = $statusCode
        ErrorCode    = $errorCode
        ErrorMessage = $errorMessage
        RawBody      = $rawBody
    }
}

function Invoke-PCloudRequestCore {
    # Single HTTP call with retry for throttling/transient errors and one re-auth on 401.
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Uri,
        [object]$Body,
        [string]$ContentType = 'application/json; charset=utf-8',
        [string]$OutFile,
        [int]$MaxRetries = 3
    )

    Initialize-PCloudTls
    $attempt = 0
    $reauthDone = $false

    while ($true) {
        $attempt++
        Update-PCloudTokenIfNeeded

        # The token lives in the session as a SecureString; it is decoded only for this request.
        $headers = @{
            'Authorization' = 'Bearer ' + (ConvertFrom-PCloudSecureString $script:PCloudSession.AccessToken)
            'Accept'        = 'application/json'
        }
        $params = @{
            Method          = $Method
            Uri             = $Uri
            Headers         = $headers
            UseBasicParsing = $true
            ErrorAction     = 'Stop'
        }
        if ($script:PCloudSession.TimeoutSec -gt 0) { $params['TimeoutSec'] = $script:PCloudSession.TimeoutSec }
        if ($script:PCloudSession.Proxy) {
            $params['Proxy'] = $script:PCloudSession.Proxy
            if ($script:PCloudSession.ProxyUseDefaultCredentials) { $params['ProxyUseDefaultCredentials'] = $true }
        }
        if ($null -ne $Body) {
            if ($Body -is [byte[]]) {
                $params['Body'] = $Body
            } else {
                if ($Body -is [string]) { $json = $Body } else { $json = ConvertTo-Json -InputObject $Body -Depth 20 -Compress }
                # Send UTF-8 bytes; PS 5.1 otherwise may mangle non-ASCII characters.
                $params['Body'] = [System.Text.Encoding]::UTF8.GetBytes($json)
            }
            $params['ContentType'] = $ContentType
        }

        Write-Verbose ("{0} {1}" -f $Method.ToUpperInvariant(), $Uri)
        try {
            if ($OutFile) {
                $params['OutFile'] = $OutFile
                Invoke-WebRequest @params | Out-Null
                return (Get-Item -LiteralPath $OutFile)
            }
            return (Invoke-RestMethod @params)
        } catch {
            $detail = Get-PCloudErrorDetail -ErrorRecord $_
            $status = $detail.StatusCode

            if ($status -eq 401 -and -not $reauthDone -and $script:PCloudSession.CanRefresh) {
                Write-Verbose 'Received 401; requesting a new token and retrying once.'
                $reauthDone = $true
                Request-PCloudToken
                $attempt--
                continue
            }
            $transient = ($status -eq 429 -or $status -eq 502 -or $status -eq 503 -or $status -eq 504)
            if ($transient -and $attempt -le $MaxRetries) {
                $delay = [int][Math]::Pow(2, $attempt)
                Write-Verbose "Received $status; retrying in $delay second(s) (attempt $attempt of $MaxRetries)."
                Start-Sleep -Seconds $delay
                continue
            }

            $msg = "Privilege Cloud API call failed: {0} {1}" -f $Method.ToUpperInvariant(), $Uri
            if ($status) { $msg += " | HTTP $status" }
            if ($detail.ErrorCode) { $msg += " | $($detail.ErrorCode)" }
            if ($detail.ErrorMessage) { $msg += " | $($detail.ErrorMessage)" }

            $exception = New-Object System.Exception($msg, $_.Exception)
            $record = New-Object System.Management.Automation.ErrorRecord($exception, 'PCloudApiError', [System.Management.Automation.ErrorCategory]::InvalidOperation, $Uri)
            $record.ErrorDetails = New-Object System.Management.Automation.ErrorDetails($msg)
            throw $record
        } finally {
            if ($Body -isnot [byte[]]) { Clear-PCloudBytes $params['Body'] }
            $headers = $null
            $params = $null
            $json = $null
        }
    }
}

function Resolve-PCloudUri {
    # Accepts 'Accounts', 'API/Accounts', '/API/Accounts' or a nextLink like 'api/Accounts?offset=50'.
    param([Parameter(Mandatory = $true)][string]$Path)
    if ($Path -match '^(?i)[a-z][a-z0-9+.-]*://') {
        # Absolute URLs (e.g. a nextLink) must point at the same Privilege Cloud host over HTTPS,
        # so the bearer token is never sent anywhere else.
        $target = [Uri]$Path
        $own = [Uri]$script:PCloudSession.PCloudUrl
        if ($target.Scheme -ne 'https' -or $target.Host -ne $own.Host) {
            throw "Refusing to send the session token to '$($target.Scheme)://$($target.Host)'. Only $($own.Host) over HTTPS is allowed."
        }
        return $Path
    }
    $p = $Path.TrimStart('/')
    if ($p -notmatch '^(?i)(api|webservices)/') { $p = 'API/' + $p }
    return $script:PCloudSession.PCloudUrl.TrimEnd('/') + '/' + $p
}
