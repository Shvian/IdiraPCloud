@{
    RootModule        = 'IdiraPCloud.psm1'
    ModuleVersion     = '2.0.1'
    GUID              = '61b823f0-567b-4394-9182-a8d071b68d98'
    Author            = 'Ian'
    Description       = 'PowerShell 5.1 functions for Idira (formerly CyberArk) Privilege Cloud REST APIs: auth, safes and safe members (limited safe-management package).'
    PowerShellVersion = '5.1'
    FunctionsToExport = @(
        'Add-PCloudSafeMember',
        'ConvertFrom-PCloudUnixTime',
        'ConvertTo-PCloudUnixTime',
        'Get-PCloudLiveSession',
        'Get-PCloudRecording',
        'Get-PCloudSafe',
        'Get-PCloudSafeMember',
        'Get-PCloudSafePermissionPreset',
        'Get-PCloudSafePermissionSet',
        'Get-PCloudSession',
        'Get-PCloudSystemHealth',
        'Invoke-PCloudApi',
        'New-PCloudSafe',
        'New-PCloudSession',
        'Resolve-PCloudSafeMemberType',
        'Remove-PCloudSafe',
        'Remove-PCloudSafeMember',
        'Remove-PCloudSession',
        'Set-PCloudSafe',
        'Set-PCloudSafeMember',
        'Update-PCloudSession',
        'Stop-PCloudLiveSession'
    )
    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()
    PrivateData       = @{
        PSData = @{
            Tags = @('CyberArk', 'Idira', 'PrivilegeCloud', 'PAM', 'REST')
        }
    }
}
