# IdiraPCloud (safe management package)

A limited build of the IdiraPCloud suite for Windows PowerShell 5.1. It contains only what Manage-Safes.ps1 needs.

```
IdiraPCloud-Safes\
  IdiraPCloud\                module: sign-in, sessions, safes, safe members, member type detection,
                              System Health (used to list CPMs), time helpers
  Scripts\_Common.ps1         loads the module and prompts for sign-in when there's no session
  Scripts\Manage-Safes.ps1    the safe management menu and actions
  Scripts\samples\safe*.csv   sample CSVs
  Tests\Test-PS51Syntax.ps1   parse check and module load test (no API calls)
```

Keep the folder layout: `_Common.ps1` loads the module from `..\IdiraPCloud\IdiraPCloud.psd1`.

```powershell
Get-ChildItem -Recurse | Unblock-File
powershell.exe -NoProfile -File .\Tests\Test-PS51Syntax.ps1
.\Scripts\Manage-Safes.ps1
```

Run `Get-Help .\Scripts\Manage-Safes.ps1 -Full` for every action, parameter and CSV column. Sign-in asks for the subdomain only. Interactive (MFA) is the default, and a service user is also offered. OLAC is not offered.
